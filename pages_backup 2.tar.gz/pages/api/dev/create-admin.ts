export { default } from '../../../src/pages/api/dev/create-admin'
