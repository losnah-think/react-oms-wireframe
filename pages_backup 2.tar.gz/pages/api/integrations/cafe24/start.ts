export { default } from '../../../../src/pages/api/integrations/cafe24/start'
