export { default } from '../../../src/pages/api/integrations/connected-shops'
