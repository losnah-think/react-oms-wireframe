export { default } from '../../../../../src/pages/api/integrations/shops/[shopId]/credentials'
