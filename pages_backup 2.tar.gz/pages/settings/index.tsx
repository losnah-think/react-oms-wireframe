import React from 'react';
const Integrations = require('../../src/pages/settings/IntegrationsPage').default;
export default function SettingsIndex() {
  return <Integrations />;
}
