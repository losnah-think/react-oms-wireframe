import React from 'react'
import ProductCategoryPage from '../../src/pages/settings/ProductCategoryPage'

const Page: React.FC = () => {
  return <ProductCategoryPage />
}

export default Page
