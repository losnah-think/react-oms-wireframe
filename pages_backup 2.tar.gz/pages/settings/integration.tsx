import React from 'react';
const IntegrationsPage = require('../../src/pages/settings/IntegrationsPage').default;
export default function IntegrationPageWrapper() {
  return <IntegrationsPage />;
}
