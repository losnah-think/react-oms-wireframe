import React, { useEffect } from 'react'
import ProductGroupPage from '../../src/pages/settings/ProductGroupPage'

const Page: React.FC = () => {
  useEffect(() => {
    // no-op
  }, [])
  return <ProductGroupPage />
}

export default Page
